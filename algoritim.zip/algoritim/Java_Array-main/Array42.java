import java.util.Scanner;

public class Array42 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int []arr = new int [n];
        int r = scanner.nextInt();

        for (int i = 0; i < n ; i++) {
            arr[i] = scanner.nextInt();
        }





    }
}
