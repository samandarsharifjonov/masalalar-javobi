import java.util.Scanner;

public class string9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String s = scanner.next();
        String s1 = scanner.next();

        String result = " ";
        result+=s+s1;
        System.out.println(result);
    }
}
