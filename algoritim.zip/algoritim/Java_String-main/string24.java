import java.util.Scanner;
public class string24 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String txt = scanner.nextLine();
        int ikkilik = Integer.parseInt(txt,2);
        System.out.println(ikkilik);
    }
}
