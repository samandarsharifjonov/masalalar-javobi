import java.util.Scanner;

public class string2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        for (char i = 0; i <= n; i++) {
            System.out.print((char) n);
            break;
        }
    }
}
