import java.util.Scanner;

public class if25 {


    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);


        double x = scanner.nextDouble();
        double y;

        if ( x < -2 || x > 2) {


            System.out.println(y = 2 * x);
        }else{


            System.out.println(y = -3 * x);

        }





    }
}
