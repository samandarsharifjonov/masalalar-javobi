import java.util.Scanner;

public class if7 {

    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);

        int a = scanner.nextInt();
        int b = scanner.nextInt();

        if (a > b) System.out.println(2);
        else System.out.println(1);


    }
}