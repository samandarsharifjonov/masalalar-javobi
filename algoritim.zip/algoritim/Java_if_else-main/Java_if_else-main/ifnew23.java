import java.util.Scanner;

public class ifnew23 {

    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);

        int x1= scanner.nextInt();
        int x2= scanner.nextInt();
        int x3= scanner.nextInt();
        int y1= scanner.nextInt();
        int y2= scanner.nextInt();
        int y3= scanner.nextInt();
        int x4=0;
        int y4=0;
        if (y2==y3){
            y1=y4;
        }
    }
}
