import java.util.Scanner;

public class bool1 {
    public static void main(String[] args) {

        Scanner kirit = new Scanner(System.in);
        System.out.println("");
        int a = kirit.nextInt();
        boolean bool = a > 0;
        System.out.println(bool);


    }
}
