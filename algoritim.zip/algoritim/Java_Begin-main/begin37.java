import java.util.Scanner;

public class begin37 {


    public static void main(String[] args) {


        Scanner kirit = new Scanner(System.in);
        System.out.print(" (0 dan farqli son kiriting) A =  ");
        float a = kirit.nextFloat();

        System.out.print(" B = ");
        float b = kirit.nextFloat();

        float x = -b / a;

        System.out.println(" X = " +x);



    }

}
