import java.util.Scanner;

public class begin28 {

    public static void main(String[] args) {


        Scanner kirit = new Scanner(System.in);

          double a = kirit.nextDouble();


        double a2 = Math.pow ( a, 2);
        double a3 = Math.pow ( a , 3);
        double a5 = Math.pow ( a , 5);
        double a10 = Math.pow( a , 10);
        double a15 = Math.pow( a, 15);

        System.out.println(a2);
        System.out.println(a3);
        System.out.println(a5);
        System.out.println(a10);
        System.out.println(a15);


    }
}
