import  java.util.Scanner;

public class begin4 {

    public static void main(String[]args) {

        double d;
        Scanner kirit = new Scanner(System.in);
        System.out.print("");
        d = kirit.nextDouble();

         double l = Math.PI * d;

        System.out.println(l);

        }

    }

