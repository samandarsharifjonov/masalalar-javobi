import java.util.Scanner;

public class begin1 {

    public static void main(String[]args){
        int a;
        int p;

        Scanner kirit = new Scanner(System.in);
        System.out.print("");
        a = kirit.nextInt();

        p = 4 * a;

        System.out.print(p);

    }
}