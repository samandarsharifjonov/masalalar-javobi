
import java.util.Scanner;
public class begin8 {

    public static void main(String[] args) {

        Scanner kirit = new Scanner(System.in);

        double a = kirit.nextDouble();
        double b = kirit.nextDouble();


        double l = ( a + b ) / 2;

        System.out.println( l);


    }

}
