import java.util.Scanner;

public class begin32 {

    public static void main(String[] args) {
        Scanner kirit = new Scanner(System.in);


        float ts = kirit.nextFloat();

        float tf = (ts * 9 / 5) + 32;

        System.out.print(tf);



    }


}
