import java.util.Scanner;

public class begin29 {


    public static void main(String[] args) {

        Scanner kirit = new Scanner(System.in);

        double a = kirit.nextDouble();


        double r =  Math.PI * a/180;
        System.out.println(r);


    }


}
