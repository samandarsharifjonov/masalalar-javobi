import java.util.Scanner;

public class begin10 {

    public static void main(String[] args) {

        Scanner kirit = new Scanner(System.in);

        double a = kirit.nextDouble();
        double b = kirit.nextDouble();

        double s = ( a + b ); // yig'indisi.
        double v = ( a * b ); // ko'paytmasi.
        double z = a * a; // a ni kvadrati.
        double x = b * b; // b ni jvadrati.

        System.out.println( s );
        System.out.println(v );
        System.out.println( z );
        System.out.println(x );



    }

}
