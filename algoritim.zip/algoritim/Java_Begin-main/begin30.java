import java.util.Scanner;

public class begin30 {


    public static void main(String[] args) {


        Scanner kirit = new Scanner(System.in);
        double pi = Math.PI;

      double r = kirit.nextDouble();

        double a = ( r * 180)/pi;
        System.out.println( a);



    }

}