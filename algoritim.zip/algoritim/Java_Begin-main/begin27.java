import java.util.Scanner;

public class begin27 {

    public static void main(String[] args) {

        double a, a2, a4, a8;

        Scanner kirit = new Scanner( System.in);
        a = kirit.nextDouble();

        a2 = ( a * a ); // a ni kvadirati.
        a4 = ( a2 * a2); // a ni 4- darajasi/
        a8 = ( a4 * a4); // a ni 8- darajasi.

        System.out.println(a2);
        System.out.println(a4);
        System.out.println(a8);


    }




}
