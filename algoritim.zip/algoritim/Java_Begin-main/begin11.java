
import java.util.Scanner;
public class begin11 {

    public static void main(String[] args) {

        Scanner kirit =new Scanner(System.in);

        double a = kirit.nextInt();


        double b = kirit.nextInt();

        double s = a + b ; // yigindisi
        double v = a * b ; // ko'paytmasi
        double z = Math.abs(a); // A ni mo'duli.
        double x = Math.abs(b); // B ni mo'duli.


        System.out.println( s);
        System.out.println( v);
        System.out.println(  z);
        System.out.println( x);


    }



}
