import java.util.Scanner;

public class begin25 {

    public static void main(String[] args) {
        Scanner kirit = new Scanner(System.in);


        double x = kirit.nextDouble();

        double y = 3 * Math.pow( x, 6) - 6 * x * x - 7;

        System.out.println( y);


    }
}
