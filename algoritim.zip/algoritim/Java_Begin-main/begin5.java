import java.util.Scanner;

public class begin5 {

    public static void main(String[] args) {

        double s, v, a;
        Scanner kirit = new Scanner(System.in);

        a = kirit.nextDouble();
        v = a * a * a;
        s = 6 * a * a;

        System.out.println( v );
        System.out.println(s);




    }
}
