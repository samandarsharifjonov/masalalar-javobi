import java.util.Scanner;
public class begin2 {

    public static void main ( String[]args){

        int a, s;

        Scanner kirit = new Scanner(System.in);
        System.out.print("");
        a = kirit.nextInt();

        s = a * a;


        System.out.print(s);



    }
}