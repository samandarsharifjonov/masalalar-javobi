import  java.util.Scanner;

public class begin9 {

    public static void main(String[] args) {


        Scanner kirit = new Scanner(System.in);

        double a = kirit.nextInt();
        double b = kirit.nextInt();

        double s = Math.sqrt( a * b);

        System.out.println(s);





    }
}
