import  java.util.Scanner;

public class begin7 {

    public static void main(String[] args) {


        Scanner kirit = new Scanner( System.in);

        float r = kirit.nextFloat();

        double p = Math.PI;
        double l = 2 * p * r; // uzunligi.
        double s = p * r * r; // yuzasi


        System.out.println( l );
        System.out.println(s);




    }
}
