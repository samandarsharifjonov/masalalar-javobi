import java.util.Scanner;
public class begin31 {

public static void main(String[] args) {
	Scanner kirit = new Scanner(System.in);

	double f = kirit.nextDouble();

	double c = (f - 32) * 5 / 9;
	System.out.println(c);
}
}

