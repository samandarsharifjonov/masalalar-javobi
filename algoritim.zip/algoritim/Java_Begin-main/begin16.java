import  java.util.Scanner;


public class begin16 {

    public static void main(String[] args) {

        Scanner kirit = new Scanner(System.in);


        double x1 = kirit.nextDouble();


        double x2 = kirit.nextDouble();

        double masofa = Math.abs(x2 - x1 );

        System.out.println( masofa);


        



    }

  }
