import java.util.Scanner;
public class begin3 {
    public static void main(String[]args){

    int a, b, s, p;

    Scanner kirit = new Scanner( System.in);
    System.out.print("");
    a = kirit.nextInt();

    System.out.print("");
    b = kirit.nextInt();

    s = a * b;
    p = 2 * ( a + b );

        System.out.println(s);
        System.out.println(p);


    }

}
