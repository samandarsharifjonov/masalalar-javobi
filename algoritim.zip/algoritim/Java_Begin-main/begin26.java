import java.util.Scanner;

public class begin26 {

    public static void main(String[] args) {


        Scanner kirit = new Scanner(System.in);

        double x = kirit.nextDouble();
        double y = 4 * Math.pow( x - 3, 6) - 7 * Math.pow(x-3, 3) + 2;

        System.out.println(y);



    }





}



