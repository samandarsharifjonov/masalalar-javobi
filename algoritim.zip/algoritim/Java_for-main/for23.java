import java.util.Scanner;

public class for23 {

}
