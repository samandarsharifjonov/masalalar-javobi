import java.util.Scanner;

public class case1 {

    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();



        switch (n){

            case 1 :
                System.out.println("dushanba");
                break;
            case 2 :
                System.out.println("seshanba");
                break;
            case 3 :
                System.out.println("chorshanba");
                break;
            case 4 :
                System.out.println("payshanba");
                break;
            case 5 :
                System.out.println("juma");
                break;
            case 6 :
                System.out.println("shanba");
                break;
            case 7 :
                System.out.println("yakshanba");
                break;
            default :
                System.out.println();
                break;

        }

    }

}
